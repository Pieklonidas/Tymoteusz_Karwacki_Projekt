#include "weapons.h"

Weapons::Weapons(sf::Texture *texture){
    setTexture(*texture);
}
